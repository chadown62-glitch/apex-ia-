"""APEX Atelier 3D : véhicules, armes et personnages paramétriques (générateurs d'APEX)."""

bl_info = {
    "name": "APEX Atelier 3D",
    "author": "APEX",
    "version": (1, 0, 0),
    "blender": (3, 6, 0),
    "location": "Vue 3D > barre latérale (N) > APEX",
    "description": "Véhicules, armes et personnages paramétriques, avec squelette lié pour les personnages",
    "category": "Add Mesh",
}

import bpy
from bpy.props import BoolProperty, EnumProperty, FloatProperty, FloatVectorProperty, IntProperty, PointerProperty

from . import mesh3d

KINDS = {
    "vehicle": [("car", "Voiture", ""), ("truck", "Camion", ""), ("tank", "Char", ""), ("motorbike", "Moto", "")],
    "weapon": [("sword", "Épée", ""), ("axe", "Hache", ""), ("rifle", "Fusil", ""), ("pistol", "Pistolet", "")],
    "character": [("humanoid", "Personnage", "")],
}

def build_scene(DATA, collection=None):
    """Construit le modèle décrit par DATA ; rend (objet racine, squelette ou None)."""
    collection = collection or bpy.context.scene.collection
    root = bpy.data.objects.new(DATA["name"], None)
    collection.objects.link(root)
    materials = {}
    for spec in DATA["materials"]:
        material = bpy.data.materials.new(spec["name"])
        material.use_nodes = True
        shader = material.node_tree.nodes.get("Principled BSDF")
        if shader is not None:
            shader.inputs["Base Color"].default_value = (*spec["color"], 1.0)
            shader.inputs["Metallic"].default_value = spec["metallic"]
            shader.inputs["Roughness"].default_value = spec["roughness"]
        material.diffuse_color = (*spec["color"], 1.0)
        materials[spec["name"]] = material
    parts = {}
    for spec in DATA["parts"]:
        mesh = bpy.data.meshes.new(spec["name"])
        mesh.from_pydata([tuple(v) for v in spec["vertices"]], [], [tuple(f) for f in spec["faces"]])
        mesh.validate()
        mesh.update()
        mesh.materials.append(materials[spec["material"]])
        obj = bpy.data.objects.new(spec["name"], mesh)
        obj.parent = root
        collection.objects.link(obj)
        parts[spec["name"]] = obj
    rig = None
    if DATA["bones"]:
        armature = bpy.data.armatures.new(DATA["name"] + "_squelette")
        rig = bpy.data.objects.new(DATA["name"] + "_squelette", armature)
        rig.parent = root
        collection.objects.link(rig)
        bpy.context.view_layer.objects.active = rig
        bpy.ops.object.mode_set(mode="EDIT")
        for spec in DATA["bones"]:
            bone = armature.edit_bones.new(spec["name"])
            bone.head, bone.tail = spec["head"], spec["tail"]
        for spec in DATA["bones"]:
            if spec["parent"]:
                armature.edit_bones[spec["name"]].parent = armature.edit_bones[spec["parent"]]
        bpy.ops.object.mode_set(mode="OBJECT")
    # Peau rigide : chaque pièce suit son os (poids 1) ; poser le squelette déplace les pièces.
    for part_name, bone_name in DATA["skin"].items():
        obj = parts[part_name]
        group = obj.vertex_groups.new(name=bone_name)
        group.add(list(range(len(obj.data.vertices))), 1.0, "REPLACE")
        modifier = obj.modifiers.new("Armature", "ARMATURE")
        modifier.object = rig
    return root, rig


def _kinds(self, context):
    return KINDS[self.generator]


class APEX_Atelier3DSettings(bpy.types.PropertyGroup):
    generator: EnumProperty(
        name="Type",
        items=[("vehicle", "Véhicule", ""), ("weapon", "Arme", ""), ("character", "Personnage", "")],
    )
    kind: EnumProperty(name="Sorte", items=_kinds)
    use_length: BoolProperty(name="Longueur", default=False)
    length: FloatProperty(name="Longueur (m)", default=4.0, min=0.1, max=30.0)
    use_width: BoolProperty(name="Largeur", default=False)
    width: FloatProperty(name="Largeur (m)", default=1.8, min=0.4, max=8.0)
    use_height: BoolProperty(name="Hauteur", default=False)
    height: FloatProperty(name="Hauteur (m)", default=1.8, min=0.5, max=8.0)
    use_wheels: BoolProperty(name="Roues", default=False)
    wheels: IntProperty(name="Roues", default=4, min=2, max=16)
    build: EnumProperty(
        name="Morphologie", items=[("slim", "Mince", ""), ("normal", "Normale", ""), ("strong", "Costaude", "")],
        default="normal",
    )
    use_color: BoolProperty(name="Couleur", default=False)
    color: FloatVectorProperty(name="Couleur", subtype="COLOR", size=3, min=0.0, max=1.0, default=(0.3, 0.36, 0.22))


class APEX_OT_build_model(bpy.types.Operator):
    """Construire le modèle (générateurs d'APEX)"""

    bl_idname = "apex.build_model"
    bl_label = "Construire"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        p = context.scene.apex_atelier3d
        options = {}
        if p.generator == "character":
            if p.use_height:
                options["height"] = p.height
            options["build"] = p.build
        else:
            if p.use_length:
                options["length"] = p.length
            if p.generator == "vehicle":
                for key in ("width", "height", "wheels"):
                    if getattr(p, "use_" + key):
                        options[key] = getattr(p, key)
        if p.use_color:
            options["color"] = tuple(p.color)
        try:
            model = mesh3d.GENERATORS[p.generator](p.kind, **options)
        except ValueError as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        if context.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        root, _rig = build_scene(mesh3d.blender_data(model), context.collection)
        root.location = context.scene.cursor.location
        stats = model.stats()
        self.report({"INFO"}, "%s : %d pièces, %d triangles, %d os" % (
            model.name, stats["parts"], stats["triangles"], stats["bones"]))
        return {"FINISHED"}


class APEX_PT_atelier3d(bpy.types.Panel):
    bl_label = "Atelier 3D"
    bl_idname = "APEX_PT_atelier3d"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "APEX"

    def draw(self, context):
        p = context.scene.apex_atelier3d
        layout = self.layout
        layout.prop(p, "generator")
        layout.prop(p, "kind")
        if p.generator == "character":
            row = layout.row()
            row.prop(p, "use_height", text="")
            row.prop(p, "height")
            layout.prop(p, "build")
        else:
            row = layout.row()
            row.prop(p, "use_length", text="")
            row.prop(p, "length")
            if p.generator == "vehicle":
                for key in ("width", "height", "wheels"):
                    row = layout.row()
                    row.prop(p, "use_" + key, text="")
                    row.prop(p, key)
        row = layout.row()
        row.prop(p, "use_color", text="")
        row.prop(p, "color")
        layout.operator("apex.build_model", icon="MESH_CUBE")


_CLASSES = (APEX_Atelier3DSettings, APEX_OT_build_model, APEX_PT_atelier3d)


def register():
    for cls in _CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Scene.apex_atelier3d = PointerProperty(type=APEX_Atelier3DSettings)


def unregister():
    del bpy.types.Scene.apex_atelier3d
    for cls in reversed(_CLASSES):
        bpy.utils.unregister_class(cls)
